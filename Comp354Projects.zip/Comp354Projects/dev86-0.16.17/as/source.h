/* source.h - global variables for source handlers for assembler */

EXTERN unsigned linum;		/* line # */
EXTERN bool_t listpre;		/* flag to show line has already been listed */
